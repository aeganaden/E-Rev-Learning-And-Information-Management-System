<!--====================================
=            Navigation Top            =
=====================================-->
<div class="row valign-wrapper">
	<div class="col s4 ">
		<a href="#"   style="padding-left: 2%" data-activates="slide-out" class="color-black button-collapse valign-wrapper">
			<i class="material-icons small">menu</i> MENU
		</a>
	</div>
	<div class="col s4">
		<center>
			<img src="<?=base_url()?>assets/img/feu-header.png" style="width: 40vh; margin-top: 2%;">
		</center> 
	</div>
	<div class="col s4"></div>
</div>

<!--====  End of Navigation Top  ====<-->