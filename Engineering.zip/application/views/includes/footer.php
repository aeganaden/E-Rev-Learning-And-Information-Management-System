
</body>

<!-- main js -->
<script type="text/javascript" src="<?=base_url()?>assets/js/main.js?v=<?=time();?>"></script>

<!-- sweet alert -->
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<!-- time table -->
<script src="<?=base_url()?>assets/js/timetable.min.js"></script>

<!-- Data tables JS -->
<script type="text/javascript" src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/1.10.16/js/dataTables.bootstrap4.min.js"></script>

<!-- charts.js -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.4.0/Chart.min.js"></script>
<!-- fittext.js -->
<script src="<?=base_url()?>assets/js/jquery.fittext.js"></script>
<!-- sticky.js -->
<script src="<?=base_url()?>assets/js/jquery.sticky.js"></script>
</html>