<div class="row valign-wrapper">
	<div class="col s4 ">
		<h3 class="center" style="text-transform: uppercase; text-align: justify-all;"><?=$data['message_l']?></h3>
	</div>
	<div class="col s4">
		<img src="<?=base_url()?>assets/chibi/Chibi_crying.svg " alt="">
	</div>	
	<div class="col s4">
		<h3 class="center" style="text-transform: uppercase; text-align: justify-all;"><?=$data['message_r']?></h3>
	</div>
</div>