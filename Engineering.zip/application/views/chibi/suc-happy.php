<div class="row valign-wrapper">
	<div class="col s4 ">
		<h5 class="center" style="text-transform: uppercase; text-align: justify-all;"><?=$data['message_l']?></h5>
	</div>
	<div class="col s4">
		<img src="<?=base_url()?>assets/chibi/Chibi_celebrate.svg " alt="">
	</div>	
	<div class="col s4">
		<h5 class="center" style="text-transform: uppercase; text-align: justify-all;"><?=$data['message_r']?></h5>
	</div>
</div>