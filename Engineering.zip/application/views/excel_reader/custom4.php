<script>document.getElementById("found_error").innerHTML = ""</script>
<script>document.getElementById("text_color").className = "red-text"</script>
<script>document.getElementById("title_icon").innerHTML = "error"</script>
<script> document.getElementById("text_title").innerHTML = "Error"</script>
