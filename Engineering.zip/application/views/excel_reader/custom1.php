<div class="container" style="margin-top:50px;">
    <span id="text_color" class="red-text" >
        <ul class="collapsible" data-collapsible="accordion">
            <li>
                <div id="title_error" class="collapsible-header">
                    <i id="title_icon" class="material-icons">error</i>
                    <span id="text_title">Error</span>
                </div>
                <div class="collapsible-body">
                    <span>