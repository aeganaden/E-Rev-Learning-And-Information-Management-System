<span id="found_error">No errors found.</span>
<script>document.getElementById("text_color").className = "green-text"</script>
<script>document.getElementById("title_icon").innerHTML = "check"</script>
<script>document.getElementById("text_title").innerHTML = "Success"</script>