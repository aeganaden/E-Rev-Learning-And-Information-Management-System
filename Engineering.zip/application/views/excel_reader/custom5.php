<div class="input-field">
    <a href="<?= base_url() ?>admin" class="waves-effect waves-light btn left red">return to home</a>
    <a href="<?= base_url() ?>importdata" class="waves-effect waves-light btn right green">upload again</a>
</div>
</div>