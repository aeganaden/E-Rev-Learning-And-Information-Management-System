<script>
    document.getElementById("text_title").innerHTML = "Error";
</script>