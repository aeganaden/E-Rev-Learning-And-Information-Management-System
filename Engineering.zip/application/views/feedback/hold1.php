<div class="row">
    <div class="col 12s">
        <span id="error" class="red-text center-align"></span>
    </div>
</div>
