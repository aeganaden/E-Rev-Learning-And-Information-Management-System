<!--====================================
=            Navigation Top            =
=====================================-->

<?php $this->load->view('includes/home-navbar'); ?>

<!--====  End of Navigation Top  ====<--></-->
<?php $this->load->view('includes/home-sidenav'); ?>
<!--ABOVE IS PERMA-->
<div class="container">
    <div class="col s12" style="margin-top: 20vh">
        <center>
            <h5  class="color-red">
                <span id="error_message"></span>
            </h5>
        </center>
    </div>
</div>
